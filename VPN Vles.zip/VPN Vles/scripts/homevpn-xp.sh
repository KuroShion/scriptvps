#!/usr/bin/env bash
# Auto-remove expired VLESS / VMess accounts
set -euo pipefail

# shellcheck disable=SC1091
source /etc/homevpn/lib.sh

require_root
load_config

if [[ ! -f "${HOMEVPN_DB}" ]]; then
  exit 0
fi

TODAY="$(date +%Y-%m-%d)"
TMP_DB="$(mktemp)"
CHANGED=0

while IFS='|' read -r proto user uuid addr sni created expiry; do
  [[ -z "${proto:-}" ]] && continue
  if [[ "${expiry}" != "never" && "${TODAY}" > "${expiry}" ]]; then
    log_info "Expiring ${proto} user '${user}' (expired on ${expiry})"
    xray_remove_user "${proto}" "${user}" || true
    rm -f "${HOMEVPN_CLIENTS}/${proto}-${user}.txt" "${HOMEVPN_CLIENTS}/${proto}-${user}.yaml"
    CHANGED=1
  else
    printf '%s|%s|%s|%s|%s|%s|%s\n' "${proto}" "${user}" "${uuid}" "${addr}" "${sni}" "${created}" "${expiry}" >> "${TMP_DB}"
  fi
done < "${HOMEVPN_DB}"

if [[ "${CHANGED}" -eq 1 ]]; then
  mv "${TMP_DB}" "${HOMEVPN_DB}"
  chmod 600 "${HOMEVPN_DB}"
else
  rm -f "${TMP_DB}"
fi
