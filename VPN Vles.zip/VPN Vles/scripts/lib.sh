#!/usr/bin/env bash
# Shared helper library for HomeVPN (WireGuard + Xray VLESS/VMess)

HOMEVPN_DIR="/etc/homevpn"
HOMEVPN_CONF="${HOMEVPN_DIR}/config.env"
HOMEVPN_DB="${HOMEVPN_DIR}/users.db"
HOMEVPN_CLIENTS="${HOMEVPN_DIR}/clients"
XRAY_BIN="/usr/local/bin/xray"
XRAY_CONF="/usr/local/etc/xray/config.json"
XRAY_CERT="/usr/local/etc/xray/xray.crt"
XRAY_KEY="/usr/local/etc/xray/xray.key"
WG_DIR="/etc/wireguard"
WG_CONF="${WG_DIR}/wg0.conf"
WG_CLIENTS="${WG_DIR}/clients"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

log_info() { echo -e "${GREEN}[INFO]${NC} $*"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
log_err()  { echo -e "${RED}[ERR ]${NC} $*" >&2; }

require_root() {
  if [[ "${EUID}" -ne 0 ]]; then
    log_err "Please run as root (e.g. sudo $0)"
    exit 1
  fi
  export HOME="/root"
}

load_config() {
  if [[ -f "${HOMEVPN_CONF}" ]]; then
    # shellcheck disable=SC1090
    source "${HOMEVPN_CONF}"
  fi
}

get_public_ip() {
  local ip=""
  for url in "https://api.ipify.org" "https://ipv4.icanhazip.com" "https://ifconfig.me/ip"; do
    ip="$(curl -4 -sS --max-time 8 "${url}" 2>/dev/null | tr -d '[:space:]')"
    if [[ "${ip}" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
      printf '%s\n' "${ip}"
      return 0
    fi
  done
  return 1
}

url_encode() {
  jq -nr --arg s "$1" '$s | @uri'
}

xray_validate_and_apply() {
  local tmp_file="$1"
  if ! jq empty "${tmp_file}" >/dev/null 2>&1; then
    log_err "Generated Xray config is not valid JSON. Aborting change."
    rm -f "${tmp_file}"
    return 1
  fi
  if ! "${XRAY_BIN}" run -test -config "${tmp_file}" >/dev/null 2>&1; then
    log_err "Xray config test failed. Aborting change."
    "${XRAY_BIN}" run -test -config "${tmp_file}" || true
    rm -f "${tmp_file}"
    return 1
  fi
  mv "${tmp_file}" "${XRAY_CONF}"
  chmod 644 "${XRAY_CONF}"
  systemctl restart xray
}

xray_add_user() {
  local proto="$1"
  local user="$2"
  local uuid="$3"
  local tmp_file
  tmp_file="$(mktemp)"

  case "${proto}" in
    vless)
      jq \
        --arg id "${uuid}" \
        --arg ev "${user}@vless-vision" \
        --arg ewt "${user}@vless-ws-tls" \
        --arg ewn "${user}@vless-ws-ntls" \
        '(.inbounds[] | select(.tag == "vless-tls") | .settings.clients) += [{"id": $id, "flow": "xtls-rprx-vision", "email": $ev}]
       | (.inbounds[] | select(.tag == "vless-ws-tls") | .settings.clients) += [{"id": $id, "email": $ewt}]
       | (.inbounds[] | select(.tag == "vless-ws-nontls") | .settings.clients) += [{"id": $id, "email": $ewn}]' \
        "${XRAY_CONF}" > "${tmp_file}"
      ;;
    vmess)
      jq \
        --arg id "${uuid}" \
        --arg ewt "${user}@vmess-ws-tls" \
        --arg ewn "${user}@vmess-ws-ntls" \
        '(.inbounds[] | select(.tag == "vmess-ws-tls") | .settings.clients) += [{"id": $id, "alterId": 0, "email": $ewt}]
       | (.inbounds[] | select(.tag == "vmess-ws-nontls") | .settings.clients) += [{"id": $id, "alterId": 0, "email": $ewn}]' \
        "${XRAY_CONF}" > "${tmp_file}"
      ;;
    *)
      rm -f "${tmp_file}"
      log_err "Unknown protocol: ${proto}"
      return 1
      ;;
  esac

  xray_validate_and_apply "${tmp_file}"
}

xray_remove_user() {
  local proto="$1"
  local user="$2"
  local tmp_file
  tmp_file="$(mktemp)"

  case "${proto}" in
    vless)
      jq \
        --arg ev "${user}@vless-vision" \
        --arg ewt "${user}@vless-ws-tls" \
        --arg ewn "${user}@vless-ws-ntls" \
        '(.inbounds[] | select(.tag == "vless-tls") | .settings.clients) |= map(select(.email != $ev))
       | (.inbounds[] | select(.tag == "vless-ws-tls") | .settings.clients) |= map(select(.email != $ewt))
       | (.inbounds[] | select(.tag == "vless-ws-nontls") | .settings.clients) |= map(select(.email != $ewn))' \
        "${XRAY_CONF}" > "${tmp_file}"
      ;;
    vmess)
      jq \
        --arg ewt "${user}@vmess-ws-tls" \
        --arg ewn "${user}@vmess-ws-ntls" \
        '(.inbounds[] | select(.tag == "vmess-ws-tls") | .settings.clients) |= map(select(.email != $ewt))
       | (.inbounds[] | select(.tag == "vmess-ws-nontls") | .settings.clients) |= map(select(.email != $ewn))' \
        "${XRAY_CONF}" > "${tmp_file}"
      ;;
    *)
      rm -f "${tmp_file}"
      log_err "Unknown protocol: ${proto}"
      return 1
      ;;
  esac

  xray_validate_and_apply "${tmp_file}"
}

db_user_exists() {
  local proto="$1"
  local user="$2"
  [[ -f "${HOMEVPN_DB}" ]] && grep -qE "^${proto}\|${user}\|" "${HOMEVPN_DB}"
}

build_and_save_client_links() {
  local proto="$1"
  local user="$2"
  local uuid="$3"
  local connect_addr="$4"
  local sni="$5"
  local created="$6"
  local expiry="$7"

  load_config
  mkdir -p "${HOMEVPN_CLIENTS}"

  local port_tls="${XRAY_PORT_TLS:-443}"
  local port_ntls="${XRAY_PORT_NONTLS:-80}"
  local path_vless_tls="${PATH_VLESS_TLS:-/vless-ws}"
  local path_vless_ntls="${PATH_VLESS_NTLS:-/vless-ws-ntls}"
  local path_vmess_tls="${PATH_VMESS_TLS:-/vmess-ws}"
  local path_vmess_ntls="${PATH_VMESS_NTLS:-/vmess-ws-ntls}"

  local allow_insecure="0"
  local skip_cert_bool="false"
  if [[ "${sni}" != "${DOMAIN}" ]]; then
    allow_insecure="1"
    skip_cert_bool="true"
  fi

  local out_txt="${HOMEVPN_CLIENTS}/${proto}-${user}.txt"
  local out_yaml="${HOMEVPN_CLIENTS}/${proto}-${user}.yaml"

  if [[ "${proto}" == "vless" ]]; then
    local sni_enc p_tls_enc p_ntls_enc r_ws_tls r_ws_ntls r_vis
    sni_enc="$(url_encode "${sni}")"
    p_tls_enc="$(url_encode "${path_vless_tls}")"
    p_ntls_enc="$(url_encode "${path_vless_ntls}")"
    r_ws_tls="$(url_encode "${user}-vless-ws-tls")"
    r_ws_ntls="$(url_encode "${user}-vless-ws-ntls")"
    r_vis="$(url_encode "${user}-vless-vision")"

    local link_ws_tls link_ws_ntls link_vision
    link_ws_tls="vless://${uuid}@${connect_addr}:${port_tls}?encryption=none&security=tls&type=ws&host=${sni_enc}&path=${p_tls_enc}&sni=${sni_enc}&allowInsecure=${allow_insecure}#${r_ws_tls}"
    link_ws_ntls="vless://${uuid}@${connect_addr}:${port_ntls}?encryption=none&security=none&type=ws&host=${sni_enc}&path=${p_ntls_enc}#${r_ws_ntls}"
    link_vision="vless://${uuid}@${connect_addr}:${port_tls}?encryption=none&security=tls&type=tcp&flow=xtls-rprx-vision&sni=${sni_enc}&allowInsecure=${allow_insecure}#${r_vis}"

    cat > "${out_txt}" <<EOF
============================================================
  VLESS Account: ${user}
============================================================
  Domain          : ${DOMAIN}
  Connect Address : ${connect_addr}
  SNI / Host      : ${sni}
  UUID            : ${uuid}
  Port TLS        : ${port_tls}
  Port None-TLS   : ${port_ntls}
  WS Path (TLS)   : ${path_vless_tls}
  WS Path (Plain) : ${path_vless_ntls}
  allowInsecure   : ${skip_cert_bool}
  Created         : ${created}
  Expires         : ${expiry}
------------------------------------------------------------
[1] VLESS WS TLS (Recommended for SNI/Host spoofing):
${link_ws_tls}

[2] VLESS WS None-TLS (Port ${port_ntls} HTTP Host):
${link_ws_ntls}

[3] VLESS TCP Vision TLS (Best direct speed):
${link_vision}
============================================================
EOF

    cat > "${out_yaml}" <<EOF
proxies:
  - name: "${user}-vless-ws-tls"
    type: vless
    server: ${connect_addr}
    port: ${port_tls}
    uuid: ${uuid}
    tls: true
    servername: ${sni}
    skip-cert-verify: ${skip_cert_bool}
    network: ws
    ws-opts:
      path: ${path_vless_tls}
      headers:
        Host: ${sni}
  - name: "${user}-vless-ws-ntls"
    type: vless
    server: ${connect_addr}
    port: ${port_ntls}
    uuid: ${uuid}
    tls: false
    network: ws
    ws-opts:
      path: ${path_vless_ntls}
      headers:
        Host: ${sni}
  - name: "${user}-vless-vision"
    type: vless
    server: ${connect_addr}
    port: ${port_tls}
    uuid: ${uuid}
    tls: true
    servername: ${sni}
    skip-cert-verify: ${skip_cert_bool}
    network: tcp
    flow: xtls-rprx-vision
EOF

  elif [[ "${proto}" == "vmess" ]]; then
    local json_tls json_ntls b64_tls b64_ntls link_tls link_ntls
    json_tls="$(jq -cn \
      --arg ps "${user}-vmess-ws-tls" \
      --arg add "${connect_addr}" \
      --arg port "${port_tls}" \
      --arg id "${uuid}" \
      --arg path "${path_vmess_tls}" \
      --arg host "${sni}" \
      '{v:"2",ps:$ps,add:$add,port:$port,id:$id,aid:"0",scy:"auto",net:"ws",type:"none",host:$host,path:$path,tls:"tls",sni:$host}')"
    json_ntls="$(jq -cn \
      --arg ps "${user}-vmess-ws-ntls" \
      --arg add "${connect_addr}" \
      --arg port "${port_ntls}" \
      --arg id "${uuid}" \
      --arg path "${path_vmess_ntls}" \
      --arg host "${sni}" \
      '{v:"2",ps:$ps,add:$add,port:$port,id:$id,aid:"0",scy:"auto",net:"ws",type:"none",host:$host,path:$path,tls:""}')"

    b64_tls="$(printf '%s' "${json_tls}" | base64 -w 0)"
    b64_ntls="$(printf '%s' "${json_ntls}" | base64 -w 0)"
    link_tls="vmess://${b64_tls}"
    link_ntls="vmess://${b64_ntls}"

    cat > "${out_txt}" <<EOF
============================================================
  VMess Account: ${user}
============================================================
  Domain          : ${DOMAIN}
  Connect Address : ${connect_addr}
  SNI / Host      : ${sni}
  UUID            : ${uuid}
  AlterID         : 0
  Port TLS        : ${port_tls}
  Port None-TLS   : ${port_ntls}
  WS Path (TLS)   : ${path_vmess_tls}
  WS Path (Plain) : ${path_vmess_ntls}
  allowInsecure   : ${skip_cert_bool} (enable in client if SNI != Domain)
  Created         : ${created}
  Expires         : ${expiry}
------------------------------------------------------------
[1] VMess WS TLS (Port ${port_tls}):
${link_tls}

[2] VMess WS None-TLS (Port ${port_ntls}):
${link_ntls}
============================================================
EOF

    cat > "${out_yaml}" <<EOF
proxies:
  - name: "${user}-vmess-ws-tls"
    type: vmess
    server: ${connect_addr}
    port: ${port_tls}
    uuid: ${uuid}
    alterId: 0
    cipher: auto
    tls: true
    servername: ${sni}
    skip-cert-verify: ${skip_cert_bool}
    network: ws
    ws-opts:
      path: ${path_vmess_tls}
      headers:
        Host: ${sni}
  - name: "${user}-vmess-ws-ntls"
    type: vmess
    server: ${connect_addr}
    port: ${port_ntls}
    uuid: ${uuid}
    alterId: 0
    cipher: auto
    tls: false
    network: ws
    ws-opts:
      path: ${path_vmess_ntls}
      headers:
        Host: ${sni}
EOF
  fi

  cat "${out_txt}"
  echo -e "${CYAN}Clash Meta/Mihomo YAML saved to:${NC} ${out_yaml}"
}
