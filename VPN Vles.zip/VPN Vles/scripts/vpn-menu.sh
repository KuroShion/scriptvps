#!/usr/bin/env bash
# HomeVPN Interactive Management CLI (WireGuard + Xray VLESS/VMess + SNI + Spaceship DDNS)
set -euo pipefail

# shellcheck disable=SC1091
source /etc/homevpn/lib.sh

require_root
load_config

pause() {
  echo ""
  read -r -n 1 -s -p "Press any key to continue..."
  echo ""
}

validate_username() {
  local name="$1"
  [[ "${name}" =~ ^[a-zA-Z0-9_-]{2,32}$ ]]
}

# ---------------------------------------------------------------------------
# Xray (VLESS / VMess) User Management
# ---------------------------------------------------------------------------

xray_add_menu() {
  local proto="$1"
  local proto_upper="${proto^^}"
  clear
  echo -e "${CYAN}=== Create ${proto_upper} User (with SNI) ===${NC}"
  local user=""
  while true; do
    read -rp "Username (letters/numbers/_/-): " user
    if ! validate_username "${user}"; then
      log_warn "Invalid username. Use 2-32 chars: a-z, A-Z, 0-9, _, -"
      continue
    fi
    if db_user_exists "${proto}" "${user}"; then
      log_warn "User '${user}' already exists in ${proto_upper}."
      continue
    fi
    break
  done

  local connect_addr="" sni="" days=""
  read -rp "Connect Address [Enter = ${DOMAIN}]: " connect_addr
  connect_addr="${connect_addr:-${DOMAIN}}"

  read -rp "SNI / Bug Host  [Enter = ${DOMAIN}]: " sni
  sni="${sni:-${DOMAIN}}"

  read -rp "Valid for how many days? (0 = Never expire) [30]: " days
  days="${days:-30}"
  if ! [[ "${days}" =~ ^[0-9]+$ ]]; then
    log_warn "Invalid days, defaulting to 30."
    days=30
  fi

  local uuid created expiry
  uuid="$(uuidgen)"
  created="$(date +%Y-%m-%d)"
  if [[ "${days}" -eq 0 ]]; then
    expiry="never"
  else
    expiry="$(date -d "+${days} days" +%Y-%m-%d)"
  fi

  xray_add_user "${proto}" "${user}" "${uuid}"

  mkdir -p "${HOMEVPN_DIR}"
  touch "${HOMEVPN_DB}"
  chmod 600 "${HOMEVPN_DB}"
  printf '%s|%s|%s|%s|%s|%s|%s\n' "${proto}" "${user}" "${uuid}" "${connect_addr}" "${sni}" "${created}" "${expiry}" >> "${HOMEVPN_DB}"

  echo ""
  build_and_save_client_links "${proto}" "${user}" "${uuid}" "${connect_addr}" "${sni}" "${created}" "${expiry}"
  pause
}

xray_list_users() {
  local proto="$1"
  echo -e "${CYAN}--- ${proto^^} Users ---${NC}"
  if [[ ! -f "${HOMEVPN_DB}" ]] || ! grep -qE "^${proto}\|" "${HOMEVPN_DB}"; then
    echo "  (none)"
    return 1
  fi
  printf "  %-18s %-24s %-22s %-12s\n" "USER" "CONNECT ADDR" "SNI/HOST" "EXPIRES"
  printf "  %-18s %-24s %-22s %-12s\n" "----" "------------" "--------" "-------"
  while IFS='|' read -r p u uuid addr sni created exp; do
    [[ "${p}" == "${proto}" ]] || continue
    printf "  %-18s %-24s %-22s %-12s\n" "${u}" "${addr}" "${sni}" "${exp}"
  done < "${HOMEVPN_DB}"
  return 0
}

xray_show_links_menu() {
  local proto="$1"
  clear
  echo -e "${CYAN}=== Show / Change SNI Links (${proto^^}) ===${NC}"
  if ! xray_list_users "${proto}"; then
    pause
    return
  fi
  echo ""
  local user=""
  read -rp "Enter username: " user
  local line
  line="$(grep -E "^${proto}\|${user}\|" "${HOMEVPN_DB}" | head -n 1 || true)"
  if [[ -z "${line}" ]]; then
    log_err "User '${user}' not found."
    pause
    return
  fi

  IFS='|' read -r _ _ uuid addr sni created exp <<< "${line}"
  echo ""
  read -rp "Preview with new Connect Address? [Enter to keep '${addr}']: " new_addr
  read -rp "Preview with new SNI / Bug Host? [Enter to keep '${sni}']: " new_sni
  new_addr="${new_addr:-${addr}}"
  new_sni="${new_sni:-${sni}}"

  # Update saved defaults in DB if changed
  if [[ "${new_addr}" != "${addr}" || "${new_sni}" != "${sni}" ]]; then
    local tmp_db
    tmp_db="$(mktemp)"
    awk -F'|' -v OFS='|' -v p="${proto}" -v u="${user}" -v na="${new_addr}" -v ns="${new_sni}" \
      '{if ($1==p && $2==u) {$4=na; $5=ns} print}' "${HOMEVPN_DB}" > "${tmp_db}"
    mv "${tmp_db}" "${HOMEVPN_DB}"
    chmod 600 "${HOMEVPN_DB}"
  fi

  echo ""
  build_and_save_client_links "${proto}" "${user}" "${uuid}" "${new_addr}" "${new_sni}" "${created}" "${exp}"
  pause
}

xray_renew_menu() {
  local proto="$1"
  clear
  echo -e "${CYAN}=== Renew ${proto^^} User ===${NC}"
  if ! xray_list_users "${proto}"; then
    pause
    return
  fi
  echo ""
  local user="" days=""
  read -rp "Enter username to renew: " user
  if ! db_user_exists "${proto}" "${user}"; then
    log_err "User '${user}' not found."
    pause
    return
  fi
  read -rp "Add days from today (0 = Never expire) [30]: " days
  days="${days:-30}"
  if ! [[ "${days}" =~ ^[0-9]+$ ]]; then
    log_err "Invalid number."
    pause
    return
  fi

  local new_exp
  if [[ "${days}" -eq 0 ]]; then
    new_exp="never"
  else
    new_exp="$(date -d "+${days} days" +%Y-%m-%d)"
  fi

  local tmp_db
  tmp_db="$(mktemp)"
  awk -F'|' -v OFS='|' -v p="${proto}" -v u="${user}" -v ne="${new_exp}" \
    '{if ($1==p && $2==u) {$7=ne} print}' "${HOMEVPN_DB}" > "${tmp_db}"
  mv "${tmp_db}" "${HOMEVPN_DB}"
  chmod 600 "${HOMEVPN_DB}"
  log_info "Renewed '${user}' (${proto^^}). New expiry: ${new_exp}"
  pause
}

xray_delete_menu() {
  local proto="$1"
  clear
  echo -e "${CYAN}=== Delete ${proto^^} User ===${NC}"
  if ! xray_list_users "${proto}"; then
    pause
    return
  fi
  echo ""
  local user=""
  read -rp "Enter username to delete: " user
  if ! db_user_exists "${proto}" "${user}"; then
    log_err "User '${user}' not found."
    pause
    return
  fi

  xray_remove_user "${proto}" "${user}"
  local tmp_db
  tmp_db="$(mktemp)"
  grep -vE "^${proto}\|${user}\|" "${HOMEVPN_DB}" > "${tmp_db}" || true
  mv "${tmp_db}" "${HOMEVPN_DB}"
  chmod 600 "${HOMEVPN_DB}"
  rm -f "${HOMEVPN_CLIENTS}/${proto}-${user}.txt" "${HOMEVPN_CLIENTS}/${proto}-${user}.yaml"
  log_info "Deleted ${proto^^} user '${user}'."
  pause
}

# ---------------------------------------------------------------------------
# WireGuard Peer Management
# ---------------------------------------------------------------------------

wg_next_ip() {
  local subnet_prefix="${WG_SUBNET_PREFIX:-10.66.66}"
  local i
  for i in $(seq 2 254); do
    local candidate="${subnet_prefix}.${i}"
    if ! grep -q "AllowedIPs = ${candidate}/32" "${WG_CONF}" 2>/dev/null; then
      printf '%s\n' "${candidate}"
      return 0
    fi
  done
  return 1
}

wg_list_peers() {
  echo -e "${CYAN}--- WireGuard Peers ---${NC}"
  local found=0
  if [[ -d "${WG_CLIENTS}" ]]; then
    for f in "${WG_CLIENTS}"/*.conf; do
      [[ -e "${f}" ]] || continue
      found=1
      local pname pip
      pname="$(basename "${f}" .conf)"
      pip="$(awk -F'= ' '/^Address/{print $2}' "${f}")"
      printf "  %-20s %s\n" "${pname}" "${pip}"
    done
  fi
  if [[ "${found}" -eq 0 ]]; then
    echo "  (none)"
    return 1
  fi
  return 0
}

wg_add_peer() {
  clear
  echo -e "${CYAN}=== Create WireGuard Peer ===${NC}"
  local peer=""
  while true; do
    read -rp "Peer name (letters/numbers/_/-): " peer
    if ! validate_username "${peer}"; then
      log_warn "Invalid name. Use 2-32 chars: a-z, A-Z, 0-9, _, -"
      continue
    fi
    if [[ -f "${WG_CLIENTS}/${peer}.conf" ]] || grep -q "### BEGIN_PEER ${peer}$" "${WG_CONF}"; then
      log_warn "Peer '${peer}' already exists."
      continue
    fi
    break
  done

  local client_ip
  client_ip="$(wg_next_ip)" || { log_err "No free IPs in subnet!"; pause; return; }

  local c_priv c_pub c_psk s_pub
  c_priv="$(wg genkey)"
  c_pub="$(printf '%s' "${c_priv}" | wg pubkey)"
  c_psk="$(wg genpsk)"
  s_pub="$(cat "${WG_DIR}/server_public.key")"

  cat >> "${WG_CONF}" <<EOF

### BEGIN_PEER ${peer}
[Peer]
PublicKey = ${c_pub}
PresharedKey = ${c_psk}
AllowedIPs = ${client_ip}/32
### END_PEER ${peer}
EOF

  wg syncconf wg0 <(wg-quick strip wg0)

  mkdir -p "${WG_CLIENTS}"
  local out_conf="${WG_CLIENTS}/${peer}.conf"
  cat > "${out_conf}" <<EOF
[Interface]
PrivateKey = ${c_priv}
Address = ${client_ip}/32
DNS = 1.1.1.1, 8.8.8.8
MTU = 1380

[Peer]
PublicKey = ${s_pub}
PresharedKey = ${c_psk}
Endpoint = ${DOMAIN}:${WG_PORT:-51820}
AllowedIPs = 0.0.0.0/0
PersistentKeepalive = 25
EOF
  chmod 600 "${out_conf}"

  echo ""
  log_info "WireGuard peer '${peer}' created (${client_ip}/32)"
  echo -e "${CYAN}Config file:${NC} ${out_conf}"
  echo "------------------------------------------------------------"
  cat "${out_conf}"
  echo "------------------------------------------------------------"
  echo -e "${CYAN}Scan QR Code in WireGuard mobile app:${NC}"
  qrencode -t ansiutf8 < "${out_conf}"
  pause
}

wg_show_peer() {
  clear
  echo -e "${CYAN}=== Show WireGuard Peer ===${NC}"
  if ! wg_list_peers; then
    pause
    return
  fi
  echo ""
  local peer=""
  read -rp "Enter peer name: " peer
  local out_conf="${WG_CLIENTS}/${peer}.conf"
  if [[ ! -f "${out_conf}" ]]; then
    log_err "Peer '${peer}' not found."
    pause
    return
  fi
  echo ""
  cat "${out_conf}"
  echo "------------------------------------------------------------"
  qrencode -t ansiutf8 < "${out_conf}"
  pause
}

wg_delete_peer() {
  clear
  echo -e "${CYAN}=== Delete WireGuard Peer ===${NC}"
  if ! wg_list_peers; then
    pause
    return
  fi
  echo ""
  local peer=""
  read -rp "Enter peer name to delete: " peer
  if [[ ! -f "${WG_CLIENTS}/${peer}.conf" ]] && ! grep -q "### BEGIN_PEER ${peer}$" "${WG_CONF}"; then
    log_err "Peer '${peer}' not found."
    pause
    return
  fi

  local tmp_wg
  tmp_wg="$(mktemp)"
  awk -v p="${peer}" '
    $0 == "### BEGIN_PEER " p {skip=1; next}
    $0 == "### END_PEER " p {skip=0; next}
    !skip {print}
  ' "${WG_CONF}" > "${tmp_wg}"
  mv "${tmp_wg}" "${WG_CONF}"
  chmod 600 "${WG_CONF}"
  rm -f "${WG_CLIENTS}/${peer}.conf"
  wg syncconf wg0 <(wg-quick strip wg0)
  log_info "Deleted WireGuard peer '${peer}'."
  pause
}

# ---------------------------------------------------------------------------
# Diagnostics, Spaceship DDNS & SSL
# ---------------------------------------------------------------------------

status_and_diagnostics() {
  clear
  echo -e "${CYAN}=== HomeVPN Status & Diagnostics ===${NC}"
  local pub_ip dns_ip lan_ip
  pub_ip="$(get_public_ip || echo 'unavailable')"
  dns_ip="$(getent ahostsv4 "${DOMAIN}" 2>/dev/null | awk '{print $1; exit}' || echo 'unresolved')"
  lan_ip="$(hostname -I | awk '{print $1}')"

  echo "Domain        : ${DOMAIN} (Root: ${ROOT_DOMAIN:-n/a}, Record: ${RECORD_NAME:-n/a})"
  echo "VM LAN IP     : ${lan_ip}"
  echo "Public IPv4   : ${pub_ip}"
  echo "Domain DNS A  : ${dns_ip}"
  if [[ "${pub_ip}" == "${dns_ip}" && "${pub_ip}" != "unavailable" ]]; then
    echo -e "DNS Match     : ${GREEN}OK (Domain points to your home IP)${NC}"
  else
    echo -e "DNS Match     : ${YELLOW}MISMATCH (Run DDNS or check Spaceship DNS)${NC}"
  fi
  echo ""
  echo -e "${CYAN}Services:${NC}"
  for svc in xray wg-quick@wg0 nginx homevpn-ddns.timer homevpn-xp.timer; do
    local st
    st="$(systemctl is-active "${svc}" 2>/dev/null || echo 'inactive')"
    if [[ "${st}" == "active" ]]; then
      printf "  %-20s : ${GREEN}%s${NC}\n" "${svc}" "${st}"
    else
      printf "  %-20s : ${YELLOW}%s${NC}\n" "${svc}" "${st}"
    fi
  done

  echo ""
  echo -e "${CYAN}SSL Certificate (${XRAY_CERT}):${NC}"
  if [[ -f "${XRAY_CERT}" ]]; then
    openssl x509 -in "${XRAY_CERT}" -noout -subject -issuer -dates | sed 's/^/  /'
  else
    echo -e "  ${RED}Missing certificate!${NC}"
  fi

  echo ""
  echo -e "${CYAN}WireGuard Active Handshakes:${NC}"
  wg show wg0 2>/dev/null | sed 's/^/  /' || echo "  wg0 not running"
  pause
}

issue_ssl_cert() {
  clear
  echo -e "${CYAN}=== Issue / Renew SSL Certificate ===${NC}"
  echo "1) Spaceship DNS-01 (Recommended - works even if ISP blocks port 80)"
  echo "2) Standalone HTTP-01 (Requires router forwarding TCP port 80 -> VM)"
  echo "0) Cancel"
  read -rp "Select [1/2/0]: " choice
  case "${choice}" in
    1)
      if [[ -z "${SPACESHIP_API_KEY:-}" || -z "${SPACESHIP_API_SECRET:-}" ]]; then
        read -rp "Spaceship API Key: " SPACESHIP_API_KEY
        read -rp "Spaceship API Secret: " SPACESHIP_API_SECRET
      fi
      export SPACESHIP_API_KEY SPACESHIP_API_SECRET
      export SPACESHIP_ROOT_DOMAIN="${ROOT_DOMAIN}"
      /root/.acme.sh/acme.sh --set-default-ca --server letsencrypt
      /root/.acme.sh/acme.sh --issue --dns dns_spaceship -d "${DOMAIN}" -k ec-256 --dnssleep 20 --force
      /root/.acme.sh/acme.sh --install-cert -d "${DOMAIN}" --ecc \
        --fullchain-file "${XRAY_CERT}" --key-file "${XRAY_KEY}" \
        --reloadcmd "systemctl restart xray"
      log_info "SSL certificate installed via Spaceship DNS-01!"
      ;;
    2)
      systemctl stop xray || true
      /root/.acme.sh/acme.sh --set-default-ca --server letsencrypt
      if /root/.acme.sh/acme.sh --issue --standalone -d "${DOMAIN}" -k ec-256 --force; then
        /root/.acme.sh/acme.sh --install-cert -d "${DOMAIN}" --ecc \
          --fullchain-file "${XRAY_CERT}" --key-file "${XRAY_KEY}" \
          --reloadcmd "systemctl restart xray"
        log_info "SSL certificate installed via HTTP-01!"
      else
        log_err "HTTP-01 failed. Check that router forwards TCP 80 -> $(hostname -I | awk '{print $1}')."
      fi
      systemctl start xray || true
      ;;
    *) return ;;
  esac
  pause
}

run_ddns_now() {
  clear
  echo -e "${CYAN}=== Running Spaceship DDNS Update ===${NC}"
  /usr/local/bin/homevpn-ddns --force || true
  echo ""
  echo -e "${CYAN}Last 10 DDNS log lines:${NC}"
  tail -n 10 /var/log/homevpn-ddns.log 2>/dev/null || echo "  (no log yet)"
  pause
}

update_xray_core() {
  clear
  echo -e "${CYAN}=== Updating Xray-core ===${NC}"
  local arch asset tmp_dir
  arch="$(uname -m)"
  case "${arch}" in
    x86_64|amd64) asset="Xray-linux-64.zip" ;;
    aarch64|arm64) asset="Xray-linux-arm64-v8a.zip" ;;
    *) log_err "Unsupported architecture: ${arch}"; pause; return ;;
  esac
  tmp_dir="$(mktemp -d)"
  curl -fsSL "https://github.com/XTLS/Xray-core/releases/latest/download/${asset}" -o "${tmp_dir}/xray.zip"
  unzip -qo "${tmp_dir}/xray.zip" -d "${tmp_dir}"
  install -m 755 "${tmp_dir}/xray" "${XRAY_BIN}"
  mkdir -p /usr/local/share/xray
  install -m 644 "${tmp_dir}/geoip.dat" "${tmp_dir}/geosite.dat" /usr/local/share/xray/
  rm -rf "${tmp_dir}"
  systemctl restart xray
  log_info "Updated Xray to: $("${XRAY_BIN}" version | head -n 1)"
  pause
}

# ---------------------------------------------------------------------------
# Submenus
# ---------------------------------------------------------------------------

submenu_xray() {
  local proto="$1"
  while true; do
    clear
    echo -e "${CYAN}=========================================${NC}"
    echo -e "  ${BOLD}${proto^^} Management (Domain: ${DOMAIN})${NC}"
    echo -e "${CYAN}=========================================${NC}"
    echo " 1) Create ${proto^^} User (with SNI)"
    echo " 2) Show Links / Change SNI Preview"
    echo " 3) Renew User"
    echo " 4) Delete User"
    echo " 5) List Users"
    echo " 0) Back"
    echo ""
    read -rp "Choose: " c
    case "${c}" in
      1) xray_add_menu "${proto}" ;;
      2) xray_show_links_menu "${proto}" ;;
      3) xray_renew_menu "${proto}" ;;
      4) xray_delete_menu "${proto}" ;;
      5) clear; xray_list_users "${proto}" || true; pause ;;
      0) return ;;
      *) ;;
    esac
  done
}

submenu_wg() {
  while true; do
    clear
    echo -e "${CYAN}=========================================${NC}"
    echo -e "  ${BOLD}WireGuard Management (UDP ${WG_PORT:-51820})${NC}"
    echo -e "${CYAN}=========================================${NC}"
    echo " 1) Create WireGuard Peer (+ QR Code)"
    echo " 2) Show Peer Config & QR Code"
    echo " 3) Delete WireGuard Peer"
    echo " 4) List Peers"
    echo " 0) Back"
    echo ""
    read -rp "Choose: " c
    case "${c}" in
      1) wg_add_peer ;;
      2) wg_show_peer ;;
      3) wg_delete_peer ;;
      4) clear; wg_list_peers || true; pause ;;
      0) return ;;
      *) ;;
    esac
  done
}

while true; do
  load_config
  clear
  echo -e "${CYAN}=================================================${NC}"
  echo -e "  ${BOLD}HomeVPN Manager${NC}  |  ${GREEN}${DOMAIN:-not-configured}${NC}"
  echo -e "${CYAN}=================================================${NC}"
  echo " 1) VLESS Menu (WS TLS / WS None-TLS / Vision + SNI)"
  echo " 2) VMess Menu (WS TLS / WS None-TLS + SNI)"
  echo " 3) WireGuard Menu (Peers + QR Codes)"
  echo " 4) Status, DNS & CGNAT Diagnostics"
  echo " 5) Run Spaceship DDNS Update Now"
  echo " 6) Issue / Renew Let's Encrypt SSL Cert"
  echo " 7) Restart Xray & WireGuard"
  echo " 8) Update Xray-core"
  echo " 0) Exit"
  echo ""
  read -rp "Select option: " opt
  case "${opt}" in
    1) submenu_xray "vless" ;;
    2) submenu_xray "vmess" ;;
    3) submenu_wg ;;
    4) status_and_diagnostics ;;
    5) run_ddns_now ;;
    6) issue_ssl_cert ;;
    7) systemctl restart xray wg-quick@wg0 nginx; log_info "Services restarted."; pause ;;
    8) update_xray_core ;;
    0) exit 0 ;;
    *) ;;
  esac
done
