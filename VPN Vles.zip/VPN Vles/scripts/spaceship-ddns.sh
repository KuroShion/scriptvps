#!/usr/bin/env bash
# Spaceship Public API Dynamic DNS (DDNS) updater for A records
set -euo pipefail

# shellcheck disable=SC1091
source /etc/homevpn/lib.sh

LOG_FILE="/var/log/homevpn-ddns.log"
CACHE_DIR="/var/lib/homevpn"
CACHE_IP_FILE="${CACHE_DIR}/last_ip"
API_BASE="https://spaceship.dev/api/v1"

FORCE_CHECK=0
if [[ "${1:-}" == "--force" ]]; then
  FORCE_CHECK=1
fi

log_ddns() {
  local msg="[$(date '+%Y-%m-%d %H:%M:%S')] $*"
  echo "${msg}" | tee -a "${LOG_FILE}"
}

require_root
load_config

if [[ -z "${SPACESHIP_API_KEY:-}" || -z "${SPACESHIP_API_SECRET:-}" || -z "${ROOT_DOMAIN:-}" || -z "${RECORD_NAME:-}" ]]; then
  log_ddns "Spaceship DDNS is not configured (missing API credentials or domain info in ${HOMEVPN_CONF})."
  exit 0
fi

mkdir -p "${CACHE_DIR}"

CURRENT_IP="$(get_public_ip || true)"
if [[ -z "${CURRENT_IP}" ]]; then
  log_ddns "ERROR: Could not determine current public IPv4."
  exit 1
fi

LAST_IP=""
if [[ -f "${CACHE_IP_FILE}" ]]; then
  LAST_IP="$(tr -d '[:space:]' < "${CACHE_IP_FILE}")"
fi

if [[ "${FORCE_CHECK}" -eq 0 && "${CURRENT_IP}" == "${LAST_IP}" ]]; then
  exit 0
fi

log_ddns "Checking Spaceship DNS for ${RECORD_NAME}.${ROOT_DOMAIN} (Current IP: ${CURRENT_IP}, Cached: ${LAST_IP:-none})..."

RESP_BODY="$(mktemp)"
HTTP_CODE="$(curl -sS -o "${RESP_BODY}" -w "%{http_code}" \
  -H "X-API-Key: ${SPACESHIP_API_KEY}" \
  -H "X-API-Secret: ${SPACESHIP_API_SECRET}" \
  -H "Accept: application/json" \
  "${API_BASE}/dns/records/${ROOT_DOMAIN}?take=500&skip=0")"

if [[ "${HTTP_CODE}" != "200" ]]; then
  log_ddns "ERROR: GET records failed (HTTP ${HTTP_CODE}): $(cat "${RESP_BODY}")"
  rm -f "${RESP_BODY}"
  exit 1
fi

EXISTING_IPS="$(jq -r --arg name "${RECORD_NAME}" \
  '.items[]? | select(.type == "A" and (.name | ascii_downcase) == ($name | ascii_downcase)) | .address' \
  "${RESP_BODY}")"
rm -f "${RESP_BODY}"

if [[ "${EXISTING_IPS}" == "${CURRENT_IP}" ]]; then
  printf '%s\n' "${CURRENT_IP}" > "${CACHE_IP_FILE}"
  log_ddns "DNS already matches ${CURRENT_IP}. Cache refreshed."
  exit 0
fi

# Delete any stale A records matching this host name before writing the new one
if [[ -n "${EXISTING_IPS}" ]]; then
  DEL_ITEMS="$(jq -cn --arg name "${RECORD_NAME}" --arg ips "${EXISTING_IPS}" \
    '[($ips | split("\n")[] | select(length > 0) | {type: "A", name: $name, address: .})]')"
  DEL_RESP="$(mktemp)"
  DEL_CODE="$(curl -sS -X DELETE -o "${DEL_RESP}" -w "%{http_code}" \
    -H "X-API-Key: ${SPACESHIP_API_KEY}" \
    -H "X-API-Secret: ${SPACESHIP_API_SECRET}" \
    -H "Content-Type: application/json" \
    --data "${DEL_ITEMS}" \
    "${API_BASE}/dns/records/${ROOT_DOMAIN}")"
  if [[ "${DEL_CODE}" != "204" && "${DEL_CODE}" != "200" ]]; then
    log_ddns "WARN: DELETE old A record returned HTTP ${DEL_CODE}: $(cat "${DEL_RESP}")"
  else
    log_ddns "Removed stale A record(s) for ${RECORD_NAME}: $(echo "${EXISTING_IPS}" | tr '\n' ' ')"
  fi
  rm -f "${DEL_RESP}"
fi

PUT_PAYLOAD="$(jq -cn --arg name "${RECORD_NAME}" --arg ip "${CURRENT_IP}" \
  '{force: true, items: [{type: "A", name: $name, address: $ip, ttl: 300}]}')"

PUT_RESP="$(mktemp)"
PUT_CODE="$(curl -sS -X PUT -o "${PUT_RESP}" -w "%{http_code}" \
  -H "X-API-Key: ${SPACESHIP_API_KEY}" \
  -H "X-API-Secret: ${SPACESHIP_API_SECRET}" \
  -H "Content-Type: application/json" \
  --data "${PUT_PAYLOAD}" \
  "${API_BASE}/dns/records/${ROOT_DOMAIN}")"

if [[ "${PUT_CODE}" != "204" && "${PUT_CODE}" != "200" ]]; then
  log_ddns "ERROR: PUT A record failed (HTTP ${PUT_CODE}): $(cat "${PUT_RESP}")"
  rm -f "${PUT_RESP}"
  exit 1
fi
rm -f "${PUT_RESP}"

printf '%s\n' "${CURRENT_IP}" > "${CACHE_IP_FILE}"
log_ddns "SUCCESS: Updated ${RECORD_NAME} (${DOMAIN}) -> ${CURRENT_IP}"
