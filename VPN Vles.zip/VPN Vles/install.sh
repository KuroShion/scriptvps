#!/usr/bin/env bash
# HomeVPN Installer for Debian (11/12/13) & Ubuntu (20.04/22.04/24.04)
# Installs: WireGuard + Xray-core (VLESS & VMess with SNI) + Nginx Fallback + Spaceship DDNS/SSL
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

info() { echo -e "${GREEN}[INFO]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
err()  { echo -e "${RED}[ERR ]${NC} $*" >&2; }

if [[ "${EUID}" -ne 0 ]]; then
  err "Please run as root: sudo bash $0"
  exit 1
fi
export HOME="/root"

if ! command -v apt-get >/dev/null 2>&1; then
  err "This installer requires Debian or Ubuntu (apt-get)."
  exit 1
fi

for req in "scripts/lib.sh" "scripts/vpn-menu.sh" "scripts/spaceship-ddns.sh" "scripts/homevpn-xp.sh"; do
  if [[ ! -f "${SCRIPT_DIR}/${req}" ]]; then
    err "Missing required file: ${SCRIPT_DIR}/${req}"
    exit 1
  fi
done

ARCH="$(uname -m)"
case "${ARCH}" in
  x86_64|amd64) XRAY_ASSET="Xray-linux-64.zip" ;;
  aarch64|arm64) XRAY_ASSET="Xray-linux-arm64-v8a.zip" ;;
  *)
    err "Unsupported CPU architecture: ${ARCH}"
    exit 1
    ;;
esac

PUB_IF="$(ip -4 route show default | awk '/default/ {print $5; exit}')"
if [[ -z "${PUB_IF}" ]]; then
  err "Could not detect default network interface."
  exit 1
fi
LAN_IP="$(hostname -I | awk '{print $1}')"

clear
echo -e "${CYAN}============================================================${NC}"
echo -e "  ${BOLD}HomeVPN Debian Installer (WireGuard + VLESS + VMess)${NC}"
echo -e "${CYAN}============================================================${NC}"
echo "  VM Architecture : ${ARCH} (${XRAY_ASSET})"
echo "  Network Iface   : ${PUB_IF}"
echo "  VM LAN IP       : ${LAN_IP}"
echo -e "${CYAN}------------------------------------------------------------${NC}"
echo ""

# ---------------------------------------------------------------------------
# Interactive Configuration
# ---------------------------------------------------------------------------
DOMAIN=""
while [[ -z "${DOMAIN}" ]]; do
  read -rp "Enter your VPN domain/subdomain (e.g. vpn.yourdomain.com): " DOMAIN
  DOMAIN="$(echo "${DOMAIN}" | tr -d '[:space:]' | tr '[:upper:]' '[:lower:]')"
done

# Suggest root domain (last two labels, user can override for .com.my / .co.uk etc.)
SUGGESTED_ROOT="$(echo "${DOMAIN}" | awk -F. '{if (NF>=2) print $(NF-1)"."$NF; else print $0}')"
read -rp "Spaceship root domain [${SUGGESTED_ROOT}]: " ROOT_DOMAIN
ROOT_DOMAIN="${ROOT_DOMAIN:-${SUGGESTED_ROOT}}"
ROOT_DOMAIN="$(echo "${ROOT_DOMAIN}" | tr -d '[:space:]' | tr '[:upper:]' '[:lower:]')"

if [[ "${DOMAIN}" == "${ROOT_DOMAIN}" ]]; then
  RECORD_NAME="@"
elif [[ "${DOMAIN}" == *".${ROOT_DOMAIN}" ]]; then
  RECORD_NAME="${DOMAIN%.${ROOT_DOMAIN}}"
else
  read -rp "Subdomain record name in Spaceship (e.g. vpn, or @ for apex): " RECORD_NAME
  RECORD_NAME="${RECORD_NAME:-@}"
fi

read -rp "Email for Let's Encrypt SSL [admin@${ROOT_DOMAIN}]: " EMAIL
EMAIL="${EMAIL:-admin@${ROOT_DOMAIN}}"

echo ""
echo -e "${CYAN}Spaceship API (Recommended for auto-DDNS + DNS-01 SSL without port 80):${NC}"
echo "  Leave blank to skip (you will need to update DNS A record manually and forward port 80)."
read -rp "Spaceship API Key    : " SPACESHIP_API_KEY
read -rp "Spaceship API Secret : " SPACESHIP_API_SECRET

echo ""
read -rp "Xray TLS Port [443]: " XRAY_PORT_TLS
XRAY_PORT_TLS="${XRAY_PORT_TLS:-443}"

read -rp "Xray None-TLS Port [80]: " XRAY_PORT_NONTLS
XRAY_PORT_NONTLS="${XRAY_PORT_NONTLS:-80}"

read -rp "WireGuard UDP Port [51820]: " WG_PORT
WG_PORT="${WG_PORT:-51820}"

PATH_VLESS_TLS="/vless-ws"
PATH_VLESS_NTLS="/vless-ws-ntls"
PATH_VMESS_TLS="/vmess-ws"
PATH_VMESS_NTLS="/vmess-ws-ntls"

echo ""
info "Installing required packages..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y \
  curl wget jq unzip socat cron ca-certificates openssl \
  wireguard wireguard-tools qrencode iptables iproute2 uuid-runtime nginx

# ---------------------------------------------------------------------------
# Install HomeVPN Scripts & Config
# ---------------------------------------------------------------------------
info "Installing management scripts..."
mkdir -p /etc/homevpn /etc/homevpn/clients /var/lib/homevpn /etc/wireguard/clients
mkdir -p /usr/local/etc/xray /usr/local/share/xray /var/log/xray

# Normalize line endings in case files were copied from Windows
tr -d '\r' < "${SCRIPT_DIR}/scripts/lib.sh" > /etc/homevpn/lib.sh
tr -d '\r' < "${SCRIPT_DIR}/scripts/vpn-menu.sh" > /usr/local/bin/vpn
tr -d '\r' < "${SCRIPT_DIR}/scripts/spaceship-ddns.sh" > /usr/local/bin/homevpn-ddns
tr -d '\r' < "${SCRIPT_DIR}/scripts/homevpn-xp.sh" > /usr/local/bin/homevpn-xp

chmod 644 /etc/homevpn/lib.sh
chmod 755 /usr/local/bin/vpn /usr/local/bin/homevpn-ddns /usr/local/bin/homevpn-xp

cat > /etc/homevpn/config.env <<EOF
DOMAIN="${DOMAIN}"
ROOT_DOMAIN="${ROOT_DOMAIN}"
RECORD_NAME="${RECORD_NAME}"
EMAIL="${EMAIL}"
SPACESHIP_API_KEY="${SPACESHIP_API_KEY}"
SPACESHIP_API_SECRET="${SPACESHIP_API_SECRET}"
XRAY_PORT_TLS="${XRAY_PORT_TLS}"
XRAY_PORT_NONTLS="${XRAY_PORT_NONTLS}"
WG_PORT="${WG_PORT}"
WG_SUBNET_PREFIX="10.66.66"
PUB_IF="${PUB_IF}"
PATH_VLESS_TLS="${PATH_VLESS_TLS}"
PATH_VLESS_NTLS="${PATH_VLESS_NTLS}"
PATH_VMESS_TLS="${PATH_VMESS_TLS}"
PATH_VMESS_NTLS="${PATH_VMESS_NTLS}"
EOF
chmod 600 /etc/homevpn/config.env
touch /etc/homevpn/users.db
chmod 600 /etc/homevpn/users.db

# ---------------------------------------------------------------------------
# Kernel Forwarding & BBR
# ---------------------------------------------------------------------------
info "Enabling IPv4 packet forwarding..."
modprobe tcp_bbr 2>/dev/null || true
cat > /etc/sysctl.d/99-homevpn.conf <<EOF
net.ipv4.ip_forward = 1
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
EOF
sysctl --system >/dev/null 2>&1 || sysctl -w net.ipv4.ip_forward=1 >/dev/null

# ---------------------------------------------------------------------------
# Nginx Local Decoy Fallback (127.0.0.1:8080 only; frees 80/443 for Xray)
# ---------------------------------------------------------------------------
info "Configuring Nginx fallback on 127.0.0.1:8080..."
rm -f /etc/nginx/sites-enabled/default
mkdir -p /var/www/homevpn
cat > /var/www/homevpn/index.html <<'EOF'
<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><title>Welcome</title></head>
<body style="font-family:sans-serif;text-align:center;margin-top:15vh;">
  <h1>Online</h1>
  <p>Service is running.</p>
</body>
</html>
EOF

cat > /etc/nginx/conf.d/homevpn-fallback.conf <<'EOF'
server {
    listen 127.0.0.1:8080 default_server;
    server_name _;
    root /var/www/homevpn;
    index index.html;

    location / {
        try_files $uri $uri/ =404;
    }
}
EOF
systemctl enable nginx >/dev/null 2>&1 || true
systemctl restart nginx

# ---------------------------------------------------------------------------
# Install Latest Official Xray-core
# ---------------------------------------------------------------------------
info "Installing latest Xray-core (${XRAY_ASSET})..."
TMP_XRAY="$(mktemp -d)"
curl -fsSL "https://github.com/XTLS/Xray-core/releases/latest/download/${XRAY_ASSET}" -o "${TMP_XRAY}/xray.zip"
unzip -qo "${TMP_XRAY}/xray.zip" -d "${TMP_XRAY}"
install -m 755 "${TMP_XRAY}/xray" /usr/local/bin/xray
install -m 644 "${TMP_XRAY}/geoip.dat" "${TMP_XRAY}/geosite.dat" /usr/local/share/xray/
rm -rf "${TMP_XRAY}"

cat > /etc/systemd/system/xray.service <<'EOF'
[Unit]
Description=Xray Service
Documentation=https://github.com/xtls
After=network-online.target nss-lookup.target
Wants=network-online.target

[Service]
User=root
CapabilityBoundingSet=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
AmbientCapabilities=CAP_NET_ADMIN CAP_NET_BIND_SERVICE
NoNewPrivileges=true
ExecStart=/usr/local/bin/xray run -config /usr/local/etc/xray/config.json
Restart=on-failure
RestartPreventExitStatus=23
LimitNPROC=10000
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF

# ---------------------------------------------------------------------------
# Spaceship DDNS Service & Timer
# ---------------------------------------------------------------------------
if [[ -n "${SPACESHIP_API_KEY}" && -n "${SPACESHIP_API_SECRET}" ]]; then
  info "Setting up Spaceship DDNS auto-updater..."
  cat > /etc/systemd/system/homevpn-ddns.service <<'EOF'
[Unit]
Description=HomeVPN Spaceship DDNS Updater
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/homevpn-ddns
EOF

  cat > /etc/systemd/system/homevpn-ddns.timer <<'EOF'
[Unit]
Description=Run HomeVPN Spaceship DDNS every 5 minutes

[Timer]
OnBootSec=1min
OnUnitActiveSec=5min
Unit=homevpn-ddns.service

[Install]
WantedBy=timers.target
EOF

  systemctl daemon-reload
  systemctl enable --now homevpn-ddns.timer
  /usr/local/bin/homevpn-ddns --force || warn "Initial Spaceship DDNS call failed; check API permissions (dnsrecords:read & dnsrecords:write)."
fi

# ---------------------------------------------------------------------------
# SSL Certificate (acme.sh via Spaceship DNS-01 or Standalone HTTP-01)
# ---------------------------------------------------------------------------
info "Installing acme.sh and issuing TLS certificate..."
if [[ ! -x /root/.acme.sh/acme.sh ]]; then
  curl -fsSL https://get.acme.sh | sh -s email="${EMAIL}"
fi

/root/.acme.sh/acme.sh --set-default-ca --server letsencrypt >/dev/null 2>&1 || true

CERT_ISSUED=0
if [[ -n "${SPACESHIP_API_KEY}" && -n "${SPACESHIP_API_SECRET}" ]]; then
  export SPACESHIP_API_KEY SPACESHIP_API_SECRET
  export SPACESHIP_ROOT_DOMAIN="${ROOT_DOMAIN}"
  if /root/.acme.sh/acme.sh --issue --dns dns_spaceship -d "${DOMAIN}" -k ec-256 --dnssleep 20; then
    /root/.acme.sh/acme.sh --install-cert -d "${DOMAIN}" --ecc \
      --fullchain-file /usr/local/etc/xray/xray.crt \
      --key-file /usr/local/etc/xray/xray.key \
      --reloadcmd "systemctl restart xray"
    CERT_ISSUED=1
  fi
else
  if /root/.acme.sh/acme.sh --issue --standalone -d "${DOMAIN}" -k ec-256; then
    /root/.acme.sh/acme.sh --install-cert -d "${DOMAIN}" --ecc \
      --fullchain-file /usr/local/etc/xray/xray.crt \
      --key-file /usr/local/etc/xray/xray.key \
      --reloadcmd "systemctl restart xray"
    CERT_ISSUED=1
  fi
fi

if [[ "${CERT_ISSUED}" -eq 0 ]]; then
  warn "Let's Encrypt cert issuance failed (DNS propagation or router port 80 not open yet)."
  warn "Generating a temporary self-signed EC-256 certificate so Xray can start."
  warn "Once DNS & port forwarding are ready, run 'sudo vpn' -> Option 6 to get a real Let's Encrypt cert."
  openssl ecparam -name prime256v1 -genkey -noout -out /usr/local/etc/xray/xray.key
  openssl req -new -x509 -days 365 -key /usr/local/etc/xray/xray.key \
    -out /usr/local/etc/xray/xray.crt -subj "/CN=${DOMAIN}"
fi
chmod 600 /usr/local/etc/xray/xray.key
chmod 644 /usr/local/etc/xray/xray.crt

# ---------------------------------------------------------------------------
# Write Xray Config (Pure JSON managed via jq)
# ---------------------------------------------------------------------------
info "Writing Xray configuration..."
DUMMY_HTTP_UUID="$(uuidgen)"

cat > /usr/local/etc/xray/config.json <<EOF
{
  "log": {
    "access": "/var/log/xray/access.log",
    "error": "/var/log/xray/error.log",
    "loglevel": "warning"
  },
  "api": {
    "tag": "api",
    "services": ["StatsService"]
  },
  "stats": {},
  "policy": {
    "levels": {
      "0": {
        "statsUserUplink": true,
        "statsUserDownlink": true
      }
    },
    "system": {
      "statsInboundUplink": true,
      "statsInboundDownlink": true
    }
  },
  "inbounds": [
    {
      "tag": "api",
      "listen": "127.0.0.1",
      "port": 10085,
      "protocol": "dokodemo-door",
      "settings": {
        "address": "127.0.0.1"
      }
    },
    {
      "tag": "vless-tls",
      "listen": "0.0.0.0",
      "port": ${XRAY_PORT_TLS},
      "protocol": "vless",
      "settings": {
        "clients": [],
        "decryption": "none",
        "fallbacks": [
          {
            "path": "${PATH_VLESS_TLS}",
            "dest": 10001,
            "xver": 1
          },
          {
            "path": "${PATH_VMESS_TLS}",
            "dest": 10002,
            "xver": 1
          },
          {
            "dest": 8080,
            "xver": 0
          }
        ]
      },
      "streamSettings": {
        "network": "tcp",
        "security": "tls",
        "tlsSettings": {
          "alpn": ["h2", "http/1.1"],
          "minVersion": "1.2",
          "certificates": [
            {
              "certificateFile": "/usr/local/etc/xray/xray.crt",
              "keyFile": "/usr/local/etc/xray/xray.key"
            }
          ]
        }
      },
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls", "quic"]
      }
    },
    {
      "tag": "vless-ws-tls",
      "listen": "127.0.0.1",
      "port": 10001,
      "protocol": "vless",
      "settings": {
        "clients": [],
        "decryption": "none"
      },
      "streamSettings": {
        "network": "ws",
        "security": "none",
        "wsSettings": {
          "acceptProxyProtocol": true,
          "path": "${PATH_VLESS_TLS}"
        }
      },
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls", "quic"]
      }
    },
    {
      "tag": "vmess-ws-tls",
      "listen": "127.0.0.1",
      "port": 10002,
      "protocol": "vmess",
      "settings": {
        "clients": []
      },
      "streamSettings": {
        "network": "ws",
        "security": "none",
        "wsSettings": {
          "acceptProxyProtocol": true,
          "path": "${PATH_VMESS_TLS}"
        }
      },
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls", "quic"]
      }
    },
    {
      "tag": "http-nontls",
      "listen": "0.0.0.0",
      "port": ${XRAY_PORT_NONTLS},
      "protocol": "vless",
      "settings": {
        "clients": [
          {
            "id": "${DUMMY_HTTP_UUID}"
          }
        ],
        "decryption": "none",
        "fallbacks": [
          {
            "path": "${PATH_VLESS_NTLS}",
            "dest": 10003,
            "xver": 1
          },
          {
            "path": "${PATH_VMESS_NTLS}",
            "dest": 10004,
            "xver": 1
          },
          {
            "dest": 8080,
            "xver": 0
          }
        ]
      },
      "streamSettings": {
        "network": "tcp",
        "security": "none"
      }
    },
    {
      "tag": "vless-ws-nontls",
      "listen": "127.0.0.1",
      "port": 10003,
      "protocol": "vless",
      "settings": {
        "clients": [],
        "decryption": "none"
      },
      "streamSettings": {
        "network": "ws",
        "security": "none",
        "wsSettings": {
          "acceptProxyProtocol": true,
          "path": "${PATH_VLESS_NTLS}"
        }
      },
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls", "quic"]
      }
    },
    {
      "tag": "vmess-ws-nontls",
      "listen": "127.0.0.1",
      "port": 10004,
      "protocol": "vmess",
      "settings": {
        "clients": []
      },
      "streamSettings": {
        "network": "ws",
        "security": "none",
        "wsSettings": {
          "acceptProxyProtocol": true,
          "path": "${PATH_VMESS_NTLS}"
        }
      },
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls", "quic"]
      }
    }
  ],
  "outbounds": [
    {
      "protocol": "freedom",
      "tag": "direct"
    },
    {
      "protocol": "blackhole",
      "tag": "blocked"
    }
  ],
  "routing": {
    "domainStrategy": "IPIfNonMatch",
    "rules": [
      {
        "type": "field",
        "inboundTag": ["api"],
        "outboundTag": "api"
      },
      {
        "type": "field",
        "ip": [
          "0.0.0.0/8",
          "10.0.0.0/8",
          "100.64.0.0/10",
          "127.0.0.0/8",
          "169.254.0.0/16",
          "172.16.0.0/12",
          "192.0.0.0/24",
          "192.0.2.0/24",
          "192.168.0.0/16",
          "198.18.0.0/15",
          "198.51.100.0/24",
          "203.0.113.0/24",
          "::1/128",
          "fc00::/7",
          "fe80::/10"
        ],
        "outboundTag": "blocked"
      },
      {
        "type": "field",
        "protocol": ["bittorrent"],
        "outboundTag": "blocked"
      }
    ]
  }
}
EOF

/usr/local/bin/xray run -test -config /usr/local/etc/xray/config.json
systemctl daemon-reload

if [[ -s /etc/homevpn/users.db ]]; then
  info "Restoring existing users from /etc/homevpn/users.db..."
  # shellcheck disable=SC1091
  source /etc/homevpn/lib.sh
  while IFS='|' read -r proto user uuid _ _ _ _; do
    [[ -n "${proto:-}" && -n "${user:-}" && -n "${uuid:-}" ]] || continue
    xray_add_user "${proto}" "${user}" "${uuid}" || warn "Could not restore ${proto}:${user}"
  done < /etc/homevpn/users.db
fi

systemctl enable --now xray
systemctl restart xray

# ---------------------------------------------------------------------------
# Configure WireGuard (wg0)
# ---------------------------------------------------------------------------
info "Configuring WireGuard on UDP port ${WG_PORT}..."
if [[ ! -f /etc/wireguard/server_private.key ]]; then
  wg genkey | tee /etc/wireguard/server_private.key | wg pubkey > /etc/wireguard/server_public.key
  chmod 600 /etc/wireguard/server_private.key
fi
WG_PRIV="$(cat /etc/wireguard/server_private.key)"

if [[ ! -f /etc/wireguard/wg0.conf ]]; then
  cat > /etc/wireguard/wg0.conf <<EOF
[Interface]
Address = 10.66.66.1/24
ListenPort = ${WG_PORT}
PrivateKey = ${WG_PRIV}
PostUp = iptables -I FORWARD 1 -i %i -j ACCEPT; iptables -I FORWARD 1 -o %i -j ACCEPT; iptables -t nat -A POSTROUTING -o ${PUB_IF} -j MASQUERADE
PostDown = iptables -D FORWARD -i %i -j ACCEPT; iptables -D FORWARD -o %i -j ACCEPT; iptables -t nat -D POSTROUTING -o ${PUB_IF} -j MASQUERADE
EOF
  chmod 600 /etc/wireguard/wg0.conf
fi

systemctl enable --now wg-quick@wg0

# ---------------------------------------------------------------------------
# Auto-Expiry Timer
# ---------------------------------------------------------------------------
cat > /etc/systemd/system/homevpn-xp.service <<'EOF'
[Unit]
Description=HomeVPN Expired Account Cleanup

[Service]
Type=oneshot
ExecStart=/usr/local/bin/homevpn-xp
EOF

cat > /etc/systemd/system/homevpn-xp.timer <<'EOF'
[Unit]
Description=Run HomeVPN Expiry Check Daily

[Timer]
OnCalendar=daily
Persistent=true
Unit=homevpn-xp.service

[Install]
WantedBy=timers.target
EOF

systemctl daemon-reload
systemctl enable --now homevpn-xp.timer

# ---------------------------------------------------------------------------
# UFW Firewall Rules (only if ufw is active)
# ---------------------------------------------------------------------------
if command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then
  info "Detected active UFW firewall — allowing VPN ports..."
  ufw allow "${XRAY_PORT_TLS}/tcp" >/dev/null || true
  ufw allow "${XRAY_PORT_NONTLS}/tcp" >/dev/null || true
  ufw allow "${WG_PORT}/udp" >/dev/null || true
  ufw route allow in on wg0 >/dev/null || true
fi

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
# shellcheck disable=SC1091
source /etc/homevpn/lib.sh
PUB_IP="$(get_public_ip || echo 'unknown')"

echo ""
echo -e "${GREEN}============================================================${NC}"
echo -e "  ${BOLD}HomeVPN Installation Complete!${NC}"
echo -e "${GREEN}============================================================${NC}"
echo "  Domain           : ${DOMAIN}"
echo "  VM LAN IP        : ${LAN_IP}"
echo "  Home Public IPv4 : ${PUB_IP}"
echo "  Xray TLS Port    : TCP ${XRAY_PORT_TLS} (VLESS Vision, VLESS WS, VMess WS)"
echo "  Xray Plain Port  : TCP ${XRAY_PORT_NONTLS} (VLESS WS None-TLS, VMess WS None-TLS)"
echo "  WireGuard Port   : UDP ${WG_PORT}"
echo ""
echo -e "  ${YELLOW}IMPORTANT — Port-Forward these on your Home Router -> ${LAN_IP}:${NC}"
echo "    - TCP ${XRAY_PORT_TLS} -> ${LAN_IP}:${XRAY_PORT_TLS}"
echo "    - TCP ${XRAY_PORT_NONTLS} -> ${LAN_IP}:${XRAY_PORT_NONTLS}"
echo "    - UDP ${WG_PORT} -> ${LAN_IP}:${WG_PORT}"
echo ""
echo -e "  Manage VPN users anytime by running: ${BOLD}sudo vpn${NC}"
echo -e "${GREEN}============================================================${NC}"
