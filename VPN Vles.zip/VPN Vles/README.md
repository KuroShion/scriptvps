# HomeVPN Debian VM Setup (WireGuard + VLESS + VMess + SNI + Spaceship DDNS)

Clean, lightweight homeserver VPN setup designed for a **Debian VM at home** using a **Spaceship domain** with a **dynamic home IP**, without the `EvoTeamMalaysia` IP lock or legacy VPS bloat.

---

## Included Services

| Service | Port | Notes |
| :--- | :--- | :--- |
| **VLESS WS TLS** | TCP `443` | Best for **SNI / Bug Host** spoofing (`path: /vless-ws`) |
| **VLESS TCP Vision** | TCP `443` | Fastest direct TLS tunnel (`flow: xtls-rprx-vision`) |
| **VMess WS TLS** | TCP `443` | Standard VMess over WebSocket TLS (`path: /vmess-ws`) |
| **VLESS WS None-TLS** | TCP `80` | Plain WebSocket + HTTP `Host` header (`path: /vless-ws-ntls`) |
| **VMess WS None-TLS** | TCP `80` | Plain WebSocket + HTTP `Host` header (`path: /vmess-ws-ntls`) |
| **WireGuard** | UDP `51820` | Fast kernel VPN + QR code generator |
| **Spaceship DDNS** | Timer (`5m`) | Auto-updates your Spaceship `A` record when your home IP changes |

---

## Step 1: Check If Your Home ISP Uses CGNAT

Because you are keeping DNS on **Spaceship** (without switching nameservers to Cloudflare), incoming traffic from your phone/laptop must reach your home router directly.

1. Log in to your home router's admin page and check its **WAN IPv4 / Internet IP**.
2. Open https://api.ipify.org from a device on your home Wi-Fi.
3. **Compare the two IPs:**
   - **If they match** -> You have a **real Public IPv4** (dynamic). Everything (WireGuard + VLESS + VMess + SNI) will work directly once you port-forward.
   - **If your router WAN IP is `100.64.x.x`, `10.x.x.x`, `192.168.x.x`, or differs from ipify** -> Your ISP uses **CGNAT**. Port forwarding from the internet into your home will **not** work on IPv4 directly; you would either need to ask your ISP for a public IPv4 (no CGNAT), use IPv6, or use a cheap relay/Cloudflare Tunnel (which requires switching nameservers).

---

## Step 2: Set a Static LAN IP & Router Port Forwarding

1. Give your **Debian VM** a static LAN IP (either inside the VM or via **DHCP Reservation** in your router, e.g., `192.168.1.50`).
   - Also make sure your VM network mode (Proxmox/VirtualBox/VMware) is **Bridged** (not NAT), so it has its own LAN IP on your router!
2. In your router's **Port Forwarding** settings, forward to your Debian VM's LAN IP:
   - **TCP `443`** -> `<VM_LAN_IP>:443` (VLESS & VMess TLS)
   - **TCP `80`** -> `<VM_LAN_IP>:80` (VLESS & VMess None-TLS / HTTP fallback)
   - **UDP `51820`** -> `<VM_LAN_IP>:51820` (WireGuard)

---

## Step 3: Create Spaceship API Keys (For Dynamic IP DDNS + SSL)

1. Log in to **Spaceship.com** -> open **API Manager** (`https://www.spaceship.com/application/api-manager`).
2. Click **+ New API key**.
3. Enable permissions **`dnsrecords:read`** and **`dnsrecords:write`** (or Full access for DNS).
4. Save the **API Key** and **API Secret** — the installer will use them for:
   - Automatic **Spaceship DDNS** (checks your home public IP every 5 minutes and updates your `A` record if it changed).
   - Automatic **Let's Encrypt SSL** via `acme.sh --dns dns_spaceship` (works even if your home ISP blocks port `80`!).

*(If you skip API keys during install, make sure your Spaceship `A` record points to your current home IP and port `80` is open before running `install.sh`.)*

---

## Step 4: Copy Files to Your Debian VM

From this Windows PC (PowerShell), copy the `VPN Vles` folder to your Debian VM using `scp`:

```powershell
scp -r "C:\Users\Kuro Shion\Desktop\VPN Vles" root@<VM_LAN_IP>:/root/homevpn-setup
```

*(Replace `root` with your Debian username if root SSH isn't enabled, then use `sudo` on the VM.)*

---

## Step 5: Run the Installer on Your Debian VM

SSH into your Debian VM and run:

```bash
cd /root/homevpn-setup
chmod +x install.sh scripts/*.sh
sudo bash install.sh
```

During installation, enter:
- Your VPN domain/subdomain (e.g., `vpn.yourdomain.com`)
- Your Spaceship root domain (e.g., `yourdomain.com`)
- Your Spaceship API Key & Secret (recommended)
- Ports (press `Enter` to accept defaults: `443`, `80`, `51820`)

---

## Step 6: Create Accounts & Configure SNI

After installation finishes, launch the management menu anytime with:

```bash
sudo vpn
```

### Using VLESS / VMess with SNI (`domain -> homeserver -> you`)
When creating a **VLESS** or **VMess** user in `sudo vpn`:
1. **Connect Address**: Press `Enter` to use your domain (`vpn.yourdomain.com`).
   - *Note:* In direct mode (without Cloudflare CDN), the Connect Address must resolve to your home router's IP (i.e., your Spaceship domain, or a wildcard subdomain pointing to it).
2. **SNI / Bug Host**: Enter the SNI / HTTP `Host` header you need (e.g., `m.facebook.com`, `www.google.com`, etc.).
3. Import the generated **`VLESS WS TLS`** or **`VMess WS TLS`** link into **v2rayNG / NekoBox / V2Box / Shadowrocket / Clash Meta**:
   - Because the TLS handshake sends your custom **SNI** while the server presents your domain's certificate, ensure **`allowInsecure` / `Skip Cert Verify` is enabled** in your client when `SNI != Domain` (the generated VLESS links and Clash YAML set this automatically).
   - For **VMess**, if your client app ignores `allowInsecure` from the `vmess://` URI, edit the imported node in v2rayNG/NekoBox and toggle **AllowInsecure = true**.

### Using WireGuard
1. Run `sudo vpn` -> **3) WireGuard Menu** -> **1) Create WireGuard Peer**.
2. Scan the terminal QR code directly with the **WireGuard** mobile app, or copy `/etc/wireguard/clients/<peer>.conf` to your PC.
3. The peer config automatically uses `Endpoint = <your-domain>:51820`, so when your home IP changes and Spaceship DDNS updates the DNS, WireGuard reconnects seamlessly.

---

## Useful Commands on the Debian VM

| Command | Purpose |
| :--- | :--- |
| `sudo vpn` | Open the interactive WireGuard / VLESS / VMess / Diagnostics menu |
| `sudo homevpn-ddns --force` | Force a Spaceship DNS `A` record check/update right now |
| `tail -f /var/log/homevpn-ddns.log` | View DDNS update history |
| `systemctl status xray wg-quick@wg0` | Check Xray and WireGuard status |
| `journalctl -u xray -n 50 --no-pager` | View Xray logs |
